from django.http import JsonResponse
from django.shortcuts import render

from .services.consultas import consultar_documentos
from .services.ia_documental import consultar_con_ollama


def consola(request):
    pregunta = request.POST.get("pregunta", "").strip()
    return render(request, "ia_local/consola.html", {"pregunta": pregunta, "respuesta": consultar_con_ollama(pregunta) if pregunta else ""})


def health(request):
    return JsonResponse({"ok": True, "servicio": "consultas documentales locales"})


def consultar(request):
    if request.method != "POST":
        return JsonResponse({"ok": False, "error": "Usa POST para enviar una pregunta."}, status=405)
    pregunta = request.POST.get("pregunta", "").strip()
    if not pregunta:
        return JsonResponse({"ok": False, "error": "Escribe una pregunta."}, status=400)
    return JsonResponse({"ok": True, "respuesta": consultar_con_ollama(pregunta)})
