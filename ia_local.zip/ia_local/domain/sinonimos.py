SINONIMOS = {
    "equipo": {"equipo", "herramienta", "maquina", "máquina"},
    "trabajo": {"trabajo", "mantencion", "mantención", "reparacion", "reparación", "servicio", "atencion", "atención"},
    "diagnostico": {"diagnostico", "diagnóstico", "problema", "evaluacion", "evaluación"},
}
