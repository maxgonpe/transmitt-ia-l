DOMINIOS = {"clientes", "equipos", "diagnosticos", "trabajos"}
OPERACIONES = {"listar", "contar", "detalle"}
CANTIDADES = {"uno", "varios", "todos"}
ORDENES = {"reciente", "antiguo", "ninguno"}


CAMPOS_AUTORIZADOS = {
    "clientes": {
        "cliente",
        "rut",
        "nombre",
        "telefono",
        "email",
        "activo",
    },

    "equipos": {
        "cliente",
        "rut",
        "numero_serie",
        "marca",
        "modelo",
        "tipo_herramienta",
        "familia",
        "combustible",
        "cilindrada",
    },

    "diagnosticos": {
        "cliente",
        "rut",
        "numero_serie",
        "estado",
        "fecha_desde",
        "fecha_hasta",
    },

    "trabajos": {
        "cliente",
        "rut",
        "numero_serie",
        "estado",
        "fecha_desde",
        "fecha_hasta",
    },
}


# ---------------------------------------------------------
# Esquema de filtros permitido para structured output.
#
# Aquí se declara explícitamente todo lo que Qwen puede
# devolver dentro de "filtros".
# ---------------------------------------------------------

FILTROS_SCHEMA = {
    "cliente": {
        "type": ["string", "null"],
    },
    "rut": {
        "type": ["string", "null"],
    },
    "nombre": {
        "type": ["string", "null"],
    },
    "telefono": {
        "type": ["string", "null"],
    },
    "email": {
        "type": ["string", "null"],
    },
    "activo": {
        "type": ["boolean", "null"],
    },
    "numero_serie": {
        "type": ["string", "null"],
    },
    "marca": {
        "type": ["string", "null"],
    },
    "modelo": {
        "type": ["string", "null"],
    },
    "tipo_herramienta": {
        "type": ["string", "null"],
    },
    "familia": {
        "type": ["string", "null"],
    },
    "combustible": {
        "type": ["string", "null"],
    },
    "cilindrada": {
        "type": ["string", "null"],
    },
    "estado": {
        "type": ["string", "null"],
    },
    "fecha_desde": {
        "type": ["string", "null"],
    },
    "fecha_hasta": {
        "type": ["string", "null"],
    },
}


SCHEMA_INTENCION = {
    "type": "object",
    "additionalProperties": False,

    "properties": {
        "tema": {
            "type": "string",
            "enum": sorted(DOMINIOS),
        },

        "operacion": {
            "type": "string",
            "enum": sorted(OPERACIONES),
        },

        "filtros": {
            "type": "object",
            "additionalProperties": False,
            "properties": FILTROS_SCHEMA,
        },

        "cantidad": {
            "type": "string",
            "enum": sorted(CANTIDADES),
        },

        "orden": {
            "type": "string",
            "enum": sorted(ORDENES),
        },
    },

    "required": [
        "tema",
        "operacion",
        "filtros",
        "cantidad",
        "orden",
    ],
}