from django.utils.formats import date_format


def _fecha(value):
    return date_format(value, "d/m/Y") if value else "sin fecha"


def construir_respuesta(resultado):
    if not resultado.get("ok"):
        return "No fue posible completar la consulta."
    tema = resultado["tema"]
    cantidad = resultado["cantidad"]
    if resultado["operacion"] == "contar":
        nombres = {"clientes": "clientes", "equipos": "equipos", "diagnosticos": "diagnósticos", "trabajos": "trabajos"}
        return f"Hay {cantidad} {nombres[tema]}."
    if not resultado["datos"]:
        return f"No encontré {tema} que coincidan con esos filtros."
    lineas = [f"Encontré {cantidad} resultado(s) en {tema}."]
    for item in resultado["datos"]:
        if tema == "clientes":
            lineas.append(f"• {item['nombre']} — RUT: {item['rut']}")
        elif tema == "equipos":
            lineas.append(f"• {item['numero_serie']} — {item['marca'] or ''} {item['modelo']} — {item['cliente']}")
        elif tema == "diagnosticos":
            lineas.append(f"• Diagnóstico #{item['id']} — {item['numero_serie']} — {item['estado']} — {_fecha(item['fecha'])}")
        else:
            lineas.append(f"• Trabajo #{item['id']} — {item['numero_serie']} — {item['estado']} — {_fecha(item['fecha_inicio'])}")
    return "\n".join(lineas)
