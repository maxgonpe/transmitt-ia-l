import re
import unicodedata

from ..domain.catalogo import (
    CAMPOS_AUTORIZADOS,
    CANTIDADES,
    DOMINIOS,
    OPERACIONES,
    ORDENES,
)

from .interprete import InterpretacionInvalida


def _texto_normalizado(value):
    value = value or ""
    value = unicodedata.normalize("NFD", value.lower())

    return "".join(
        char
        for char in value
        if unicodedata.category(char) != "Mn"
    )


def _filtro_vacio(valor):
    return (
        valor is None
        or valor == ""
        or valor == []
        or valor == {}
    )


def normalizar_intencion(raw, pregunta=""):

    if not isinstance(raw, dict):
        raise InterpretacionInvalida(
            "La intención no es un objeto"
        )

    tema = raw.get("tema")
    operacion = raw.get("operacion")
    filtros = raw.get("filtros", {})
    cantidad = raw.get("cantidad", "varios")
    orden = raw.get("orden", "ninguno")

    # --------------------------------------------------
    # Validación general
    # --------------------------------------------------

    if tema not in DOMINIOS:
        raise InterpretacionInvalida(
            f"Tema no autorizado: {tema}"
        )

    if operacion not in OPERACIONES:
        raise InterpretacionInvalida(
            f"Operación no autorizada: {operacion}"
        )

    if not isinstance(filtros, dict):
        raise InterpretacionInvalida(
            "Los filtros deben ser un objeto"
        )

    # --------------------------------------------------
    # Eliminar filtros vacíos generados por el modelo
    # --------------------------------------------------

    filtros = {
        clave: valor
        for clave, valor in filtros.items()
        if not _filtro_vacio(valor)
    }

    # --------------------------------------------------
    # Validar filtros según dominio
    # --------------------------------------------------

    filtros_no_autorizados = (
        set(filtros)
        - CAMPOS_AUTORIZADOS[tema]
    )

    if filtros_no_autorizados:
        raise InterpretacionInvalida(
            "Filtro no autorizado: "
            + ", ".join(sorted(filtros_no_autorizados))
        )

    if cantidad not in CANTIDADES:
        raise InterpretacionInvalida(
            f"Cantidad no autorizada: {cantidad}"
        )

    if orden not in ORDENES:
        raise InterpretacionInvalida(
            f"Orden no autorizado: {orden}"
        )

    # --------------------------------------------------
    # Normalización lingüística determinista
    # --------------------------------------------------

    texto = _texto_normalizado(pregunta)

    if re.search(
        r"\b(cuantos|cuantas|cantidad|total|numero de)\b",
        texto,
    ):
        operacion = "contar"

    elif re.search(
        r"\b(lista|listame|muestrame|dame|cuales)\b",
        texto,
    ):
        operacion = "listar"
        cantidad = "varios"

    if re.search(
        r"\b(ultimo|ultima|reciente|primero|primera)\b",
        texto,
    ):
        cantidad = "uno"

        if re.search(
            r"\b(ultimo|ultima|reciente)\b",
            texto,
        ):
            orden = "reciente"
        else:
            orden = "antiguo"

    return {
        "tema": tema,
        "operacion": operacion,
        "filtros": filtros,
        "cantidad": cantidad,
        "orden": orden,
    }