from django.conf import settings
from .proveedor import AIProvider


class OllamaError(RuntimeError):
    """Controlled failure when the local AI provider is unavailable."""


class OllamaProvider(AIProvider):
    def __init__(self, base_url=None, model=None, timeout=None):
        self.base_url = (base_url or settings.IA_OLLAMA_URL).rstrip("/")
        self.model = model or settings.IA_OLLAMA_MODEL
        self.timeout = timeout or settings.IA_OLLAMA_TIMEOUT

    def healthcheck(self):
        import requests

        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=self.timeout)
            response.raise_for_status()
            return True
        except requests.RequestException as exc:
            raise OllamaError("Ollama no está disponible") from exc

    def model_available(self):
        import requests

        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=self.timeout)
            response.raise_for_status()
            names = {item.get("name") for item in response.json().get("models", [])}
            return self.model in names
        except (requests.RequestException, ValueError) as exc:
            raise OllamaError("No se pudo consultar Ollama") from exc

    def structured_chat(self, messages, schema):
        import requests

        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "format": schema,
            "options": {"temperature": settings.IA_OLLAMA_TEMPERATURE},
        }
        try:
            response = requests.post(
                f"{self.base_url}/api/chat", json=payload, timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()
            return data.get("message", {}).get("content", "")
        except (requests.RequestException, ValueError, TypeError) as exc:
            raise OllamaError("No se pudo obtener una respuesta estructurada") from exc
