from .consultas import consultar_documentos
from .semantica import procesar_pregunta


def consultar_con_ollama(pregunta):
    """Interpreta con Ollama y mantiene la consulta determinista como respaldo."""
    try:
        resultado = procesar_pregunta(pregunta)
        return resultado["resultado"]["respuesta"]
    except Exception:
        return consultar_documentos(pregunta)
