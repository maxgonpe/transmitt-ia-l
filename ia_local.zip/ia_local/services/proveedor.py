from abc import ABC, abstractmethod


class AIProvider(ABC):
    @abstractmethod
    def healthcheck(self):
        raise NotImplementedError

    @abstractmethod
    def model_available(self):
        raise NotImplementedError

    @abstractmethod
    def structured_chat(self, messages, schema):
        raise NotImplementedError
