"""Capa semántica documental: lenguaje natural -> plan seguro -> ORM determinista."""

from __future__ import annotations

import json
import re
import unicodedata
from datetime import date, timedelta
from typing import Any

from django.db.models import Q

from documents.models import Document, DocumentAttachment, Folder, FolderFile
from transmital.models import Transmital

from .ollama import OllamaError, OllamaProvider


TEMAS = {"documentos", "transmittals", "carpetas", "adjuntos"}
OPERACIONES = {"listar", "contar"}
MAX_LIMITE = 50

CAMPOS_POR_DEFECTO = {
    "documentos": ["codigo", "titulo", "estado", "fecha"],
    "transmittals": ["codigo", "fecha_envio", "destinatario", "empresa"],
    "carpetas": ["codigo", "titulo", "fecha"],
    "adjuntos": ["archivo", "documento", "fecha"],
}
CAMPOS_PERMITIDOS = {
    "id", "codigo", "titulo", "descripcion", "estado", "fecha", "fecha_envio",
    "archivo", "documento", "destinatario", "empresa", "revision", "proyecto",
    "compania", "proceso", "tipo_documento", "cantidad_adjuntos",
}

PLAN_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "tema": {"type": "string", "enum": sorted(TEMAS)},
        "operacion": {"type": "string", "enum": sorted(OPERACIONES)},
        "codigo": {"type": ["string", "null"]},
        "texto": {"type": ["string", "null"]},
        "estado": {"type": ["string", "null"]},
        "proyecto": {"type": ["string", "null"]},
        "compania": {"type": ["string", "null"]},
        "proceso": {"type": ["string", "null"]},
        "tipo_documento": {"type": ["string", "null"]},
        "fecha_desde": {"type": ["string", "null"]},
        "fecha_hasta": {"type": ["string", "null"]},
        "orden_campo": {"type": "string", "enum": ["fecha", "codigo", "id"]},
        "orden_direccion": {"type": "string", "enum": ["asc", "desc"]},
        "limite": {"type": "integer", "minimum": 1, "maximum": 50},
        "campos": {"type": "array", "items": {"type": "string", "enum": sorted(CAMPOS_PERMITIDOS)}, "maxItems": 20},
    },
    "required": [
        "tema", "operacion", "codigo", "texto", "estado", "proyecto", "compania",
        "proceso", "tipo_documento", "fecha_desde", "fecha_hasta", "orden_campo",
        "orden_direccion", "limite", "campos",
    ],
}

PROMPT = """
Eres el intérprete semántico de un sistema de control documental.
Tu única función es convertir una pregunta en el JSON del esquema recibido.
Devuelve exclusivamente JSON. No respondas, no inventes datos, no escribas SQL ni ORM.

VOCABULARIO:
- documento, archivo, plano, registro -> documentos
- transmittal, transmital, TTAL, envío -> transmittals
- carpeta, folder -> carpetas
- adjunto, archivo adjunto -> adjuntos
- código completo, TTAL-184 o 184 -> codigo
- proyecto, empresa ejecutora, proceso y tipo de documento son filtros separados
- "cuántos", "cuántas", "cantidad" o "total" -> contar
- "cuáles", "qué", "lista", "lístame", "muéstrame" o "números" -> listar
- "último" o "más reciente" -> orden_campo fecha, orden_direccion desc, limite 1
- "primero" o "más antiguo" -> orden_campo fecha, orden_direccion asc, limite 1
- un mes completo debe convertirse a fecha_desde y fecha_hasta inclusivas en YYYY-MM-DD
- si no hay filtro, usa null; no inventes nombres ni códigos.
Para consultas sobre transmittals registrados, usa la fecha funcional de envío.
Para una pregunta sobre fecha de carga/importación, usa igualmente el período solicitado;
la aplicación decidirá la fuente de fecha autorizada.
"""


def _texto(texto: str) -> str:
    normalizado = unicodedata.normalize("NFD", texto or "").lower()
    return "".join(c for c in normalizado if unicodedata.category(c) != "Mn")


def _periodo(pregunta: str):
    """Fallback de fechas para que Ollama no sea imprescindible."""
    texto = _texto(pregunta)
    meses = {
        "enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6,
        "julio": 7, "agosto": 8, "septiembre": 9, "setiembre": 9, "octubre": 10,
        "noviembre": 11, "diciembre": 12,
    }
    anio_match = re.search(r"\b(20\d{2})\b", texto)
    anio = int(anio_match.group(1)) if anio_match else date.today().year
    for nombre, mes in meses.items():
        if re.search(rf"\b{nombre}\b", texto):
            inicio = date(anio, mes, 1)
            fin = date(anio + (mes == 12), 1 if mes == 12 else mes + 1, 1) - timedelta(days=1)
            return inicio.isoformat(), fin.isoformat()
    iso = re.search(r"\b(20\d{2})-(\d{1,2})-(\d{1,2})\b", texto)
    europea = re.search(r"\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b", texto)
    if iso:
        valor = date(*(int(x) for x in iso.groups())).isoformat()
        return valor, valor
    if europea:
        dia, mes, anio = (int(x) for x in europea.groups())
        valor = date(anio, mes, dia).isoformat()
        return valor, valor
    return None, None


def _extraer_codigo(pregunta: str) -> str | None:
    match = re.search(r"(?:ODATA|TRN|PROY)[A-Z0-9-]*-\d{1,6}|\bTTAL[- ]?\d{1,6}\b", pregunta.upper())
    if match:
        return match.group(0).replace(" ", "-")
    if re.search(r"\b(transmittal|transmital|ttal)\b", _texto(pregunta)):
        match = re.search(r"\b(\d{1,6})\b", pregunta)
        return match.group(1) if match else None
    return None


def validar_plan(plan: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(plan, dict) or plan.get("tema") not in TEMAS or plan.get("operacion") not in OPERACIONES:
        raise ValueError("Plan semántico no permitido.")
    for campo in ("fecha_desde", "fecha_hasta"):
        valor = plan.get(campo)
        if valor:
            date.fromisoformat(valor)
    limite = plan.get("limite", 20)
    try:
        plan["limite"] = min(max(int(limite), 1), MAX_LIMITE)
    except (TypeError, ValueError):
        plan["limite"] = 20
    if plan.get("orden_campo") not in {"fecha", "codigo", "id"}:
        plan["orden_campo"] = "fecha"
    if plan.get("orden_direccion") not in {"asc", "desc"}:
        plan["orden_direccion"] = "desc"
    plan["campos"] = [campo for campo in (plan.get("campos") or []) if campo in CAMPOS_PERMITIDOS]
    for campo in ("codigo", "texto", "estado", "proyecto", "compania", "proceso", "tipo_documento"):
        valor = plan.get(campo)
        if isinstance(valor, str):
            plan[campo] = valor.strip()[:100] or None
        elif valor is not None:
            plan[campo] = None
    return plan


def normalizar_intencion(pregunta: str, plan: dict[str, Any]) -> dict[str, Any]:
    texto = _texto(pregunta)
    if re.search(r"\badjunt|ficher|archivo adicional", texto):
        plan["tema"] = "adjuntos"
        plan["operacion"] = "contar" if any(p in texto for p in ("cuant", "total", "cantidad")) else "listar"
    if plan.get("tema") == "transmittals":
        if plan.get("texto") in {"transmittal", "transmittals", "transmital", "ttal", "envio", "envíos"}:
            plan["texto"] = None
        # Qwen sometimes mistakes the year in a date for the numeric TTAL reference.
        if isinstance(plan.get("codigo"), str) and re.fullmatch(r"20\d{2}", plan["codigo"]):
            plan["codigo"] = None
        plan["tipo_documento"] = None
    if any(p in texto for p in ("lista", "listame", "muestrame", "cuales", "numeros", "que ")):
        plan["operacion"] = "listar"
    elif any(p in texto for p in ("cuantos", "cuantas", "cantidad", "total")):
        plan["operacion"] = "contar"
    pide_unico = bool(re.search(r"\b(el|la)\s+(ultimo|ultima|primero|primera)\b", texto))
    if plan["operacion"] == "listar":
        if pide_unico:
            plan["limite"] = 1
            plan["orden_direccion"] = "asc" if "primer" in texto else "desc"
        elif "todos" in texto or "todas" in texto:
            plan["limite"] = MAX_LIMITE
        elif plan.get("limite", 20) <= 1:
            plan["limite"] = 20
        if not plan.get("campos"):
            plan["campos"] = CAMPOS_POR_DEFECTO[plan["tema"]]
    if not plan.get("codigo"):
        plan["codigo"] = _extraer_codigo(pregunta)
        if plan.get("codigo") and re.fullmatch(r"20\d{2}", plan["codigo"]):
            plan["codigo"] = None
    if not plan.get("fecha_desde") and not plan.get("fecha_hasta"):
        plan["fecha_desde"], plan["fecha_hasta"] = _periodo(pregunta)
    return validar_plan(plan)


def interpretar_pregunta(pregunta: str) -> dict[str, Any]:
    if not pregunta or not pregunta.strip():
        raise ValueError("La pregunta no puede estar vacía.")
    try:
        provider = OllamaProvider()
        contenido = provider.structured_chat(
            [{"role": "system", "content": PROMPT}, {"role": "user", "content": pregunta.strip()}],
            PLAN_SCHEMA,
        )
        return normalizar_intencion(pregunta, validar_plan(json.loads(contenido)))
    except (OllamaError, ImportError, TypeError, ValueError, json.JSONDecodeError):
        tema = "transmittals" if re.search(r"transmit|ttal", _texto(pregunta)) else "documentos"
        plan = {campo: None for campo in PLAN_SCHEMA["properties"]}
        plan.update({"tema": tema, "operacion": "contar", "orden_campo": "fecha", "orden_direccion": "desc", "limite": 20, "campos": []})
        return normalizar_intencion(pregunta, plan)


def ejecutar_plan(plan: dict[str, Any]) -> dict[str, Any]:
    tema = plan["tema"]
    if tema == "documentos":
        qs = Document.objects.select_related("project", "company", "process", "doc_type", "folder")
        fecha = "date"
        qs = _filtrar_documentos(qs, plan)
    elif tema == "transmittals":
        qs = Transmital.objects.all()
        fecha = "fecha_envio"
        qs = _filtrar_transmittals(qs, plan)
    elif tema == "carpetas":
        qs = Folder.objects.all()
        fecha = "date"
        qs = _filtrar_texto_fecha(qs, plan, ("code", "title", "description"), fecha)
    else:
        qs = DocumentAttachment.objects.select_related("document")
        fecha = "created_at"
        qs = _filtrar_texto_fecha(qs, plan, ("file", "extracted_text", "document__code"), fecha)
        if plan.get("codigo"):
            codigo = plan["codigo"]
            if codigo.isdigit():
                codigo = f"TTAL-{int(codigo):05d}"
            qs = qs.filter(document__code__iendswith=codigo)
    total = qs.count()
    if plan["operacion"] == "contar":
        return {"ok": True, "tema": tema, "operacion": "contar", "total": total, "cantidad": total, "datos": []}
    order = fecha if plan["orden_campo"] == "fecha" else plan["orden_campo"]
    if plan["orden_direccion"] == "desc":
        order = f"-{order}"
    datos = list(qs.order_by(order, "-pk")[:plan["limite"]])
    serializados = [_serializar(obj, tema) for obj in datos]
    return {"ok": True, "tema": tema, "operacion": "listar", "total": total, "cantidad": len(serializados), "datos": serializados}


def _filtrar_texto_fecha(qs, plan, campos, fecha):
    if plan.get("texto"):
        condiciones = Q()
        for campo in campos:
            condiciones |= Q(**{f"{campo}__icontains": plan["texto"]})
        qs = qs.filter(condiciones)
    if plan.get("fecha_desde"):
        qs = qs.filter(**{f"{fecha}__date__gte": plan["fecha_desde"]} if "created" in fecha else {f"{fecha}__gte": plan["fecha_desde"]})
    if plan.get("fecha_hasta"):
        qs = qs.filter(**{f"{fecha}__date__lte": plan["fecha_hasta"]} if "created" in fecha else {f"{fecha}__lte": plan["fecha_hasta"]})
    return qs


def _filtrar_documentos(qs, plan):
    if plan.get("codigo"): qs = qs.filter(code__icontains=plan["codigo"] if not plan["codigo"].isdigit() else f"TTAL-{int(plan['codigo']):05d}")
    if plan.get("texto"): qs = qs.filter(Q(title__icontains=plan["texto"]) | Q(description__icontains=plan["texto"]) | Q(content_extract__icontains=plan["texto"]))
    if plan.get("estado"): qs = qs.filter(status__icontains=plan["estado"])
    if plan.get("proyecto"): qs = qs.filter(project__code__icontains=plan["proyecto"])
    if plan.get("compania"): qs = qs.filter(company__code__icontains=plan["compania"])
    if plan.get("proceso"): qs = qs.filter(process__code__icontains=plan["proceso"])
    if plan.get("tipo_documento"): qs = qs.filter(doc_type__code__icontains=plan["tipo_documento"])
    return _filtrar_texto_fecha(qs, plan, (), "date")


def _filtrar_transmittals(qs, plan):
    if plan.get("codigo"):
        codigo = plan["codigo"]
        qs = qs.filter(Q(codigo_transmital__iexact=codigo) | Q(codigo_transmital__iendswith=f"TTAL-{int(codigo):05d}" if codigo.isdigit() else codigo))
    if plan.get("texto"):
        qs = qs.filter(Q(codigo_transmital__icontains=plan["texto"]) | Q(destinatario__icontains=plan["texto"]) | Q(empresa__icontains=plan["texto"]) | Q(referencia__icontains=plan["texto"]))
    return _filtrar_texto_fecha(qs, plan, (), "fecha_envio")


def _serializar(obj, tema):
    if tema == "documentos":
        return {"id": obj.pk, "codigo": obj.code, "titulo": obj.title, "estado": obj.get_status_display(), "fecha": obj.date.isoformat(), "cantidad_adjuntos": obj.attachments.count()}
    if tema == "transmittals":
        return {"id": obj.pk, "codigo": obj.codigo_transmital, "consecutivo": obj.consecutivo, "fecha_envio": obj.fecha_envio.isoformat() if obj.fecha_envio else None, "destinatario": obj.destinatario, "empresa": obj.empresa}
    if tema == "carpetas":
        return {"id": obj.pk, "codigo": obj.code, "titulo": obj.title, "fecha": obj.date.isoformat()}
    return {"id": obj.pk, "archivo": obj.file.name, "documento": obj.document.code, "fecha": obj.created_at.isoformat()}


def construir_respuesta(resultado):
    if not resultado.get("ok"): return "No fue posible completar la consulta."
    nombres = {"documentos": "documentos", "transmittals": "transmittals", "carpetas": "carpetas", "adjuntos": "adjuntos"}
    nombre = nombres[resultado["tema"]]
    if resultado["operacion"] == "contar": return f"Encontré {resultado['total']} {nombre} que cumplen la consulta."
    if not resultado["datos"]: return f"No encontré {nombre} que cumplan los criterios."
    lineas = [f"Encontré {resultado['total']} {nombre}. Mostrando {resultado['cantidad']}:"]
    for dato in resultado["datos"]:
        lineas.append("- " + " | ".join(f"{clave}: {valor}" for clave, valor in dato.items() if valor not in (None, "")))
    return "\n".join(lineas)


def procesar_pregunta(pregunta):
    plan = interpretar_pregunta(pregunta)
    resultado = ejecutar_plan(plan)
    resultado["respuesta"] = construir_respuesta(resultado)
    return {"plan": plan, "resultado": resultado}
