import re
import unicodedata
from datetime import date, datetime, timedelta

from django.utils import timezone
from documents.models import Document, DocumentAttachment, Folder, FolderFile
from transmital.models import Transmital


MESES = {
    "ENERO": 1,
    "FEBRERO": 2,
    "MARZO": 3,
    "ABRIL": 4,
    "MAYO": 5,
    "JUNIO": 6,
    "JULIO": 7,
    "AGOSTO": 8,
    "SEPTIEMBRE": 9,
    "SETIEMBRE": 9,
    "OCTUBRE": 10,
    "NOVIEMBRE": 11,
    "DICIEMBRE": 12,
}


def _normalizar(texto):
    texto = unicodedata.normalize("NFD", texto or "")
    return "".join(c for c in texto.upper() if unicodedata.category(c) != "Mn")


def resolver_referencia(referencia):
    """Encuentra un Documento o Carpeta con código completo, TTAL-184 o 184."""
    referencia = referencia.strip().upper()
    if not referencia:
        return None, None

    documento = Document.objects.filter(code__iexact=referencia).first()
    if documento:
        return "documento", documento

    match = re.fullmatch(r"(?:TTAL[- ]?)?(\d{1,6})", referencia)
    if match:
        numero = int(match.group(1))
        documento = Document.objects.filter(number=numero, code__iendswith=f"TTAL-{numero:05d}").first()
        if documento:
            return "documento", documento
        carpeta = Folder.objects.filter(code__iendswith=f"TTAL-{numero:05d}").first()
        if carpeta:
            return "carpeta", carpeta

    carpeta = Folder.objects.filter(code__iexact=referencia).first()
    return ("carpeta", carpeta) if carpeta else (None, None)


def contar_adjuntos(referencia):
    tipo, objeto = resolver_referencia(referencia)
    if not objeto:
        return {"ok": False, "respuesta": f"No encontré un documento o transmittal con la referencia {referencia}."}

    if tipo == "documento":
        cantidad = DocumentAttachment.objects.filter(document=objeto).count()
        return {
            "ok": True,
            "cantidad": cantidad,
            "referencia": objeto.code,
            "detalle": "adjuntos adicionales del documento",
        }

    cantidad = FolderFile.objects.filter(folder=objeto).count()
    return {"ok": True, "cantidad": cantidad, "referencia": objeto.code, "detalle": "archivos de la carpeta"}


def _periodo_registro(pregunta):
    """Devuelve el rango de fecha mencionado en una pregunta."""
    texto = _normalizar(pregunta)
    ahora = timezone.localdate()

    mes_nombre = next((mes for mes in MESES if re.search(rf"\b{mes}\b", texto)), None)
    anio_match = re.search(r"\b(20\d{2})\b", texto)
    anio = int(anio_match.group(1)) if anio_match else ahora.year

    if mes_nombre:
        mes = MESES[mes_nombre]
        inicio = date(anio, mes, 1)
        fin = date(anio + (mes == 12), 1 if mes == 12 else mes + 1, 1)
        return inicio, fin, f"{mes_nombre.title()} de {anio}"

    iso_match = re.search(r"\b(20\d{2})-(\d{1,2})-(\d{1,2})\b", texto)
    fecha_match = re.search(r"\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b", texto)
    if iso_match:
        inicio = date(*(int(parte) for parte in iso_match.groups()))
    elif fecha_match:
        dia, mes, anio = (int(parte) for parte in fecha_match.groups())
        inicio = date(anio, mes, dia)
    else:
        return None
    return inicio, inicio + timedelta(days=1), inicio.strftime("%d/%m/%Y")


def consultar_transmittals(pregunta):
    periodo = _periodo_registro(pregunta)
    if not periodo:
        return None

    inicio, fin, etiqueta = periodo
    texto = _normalizar(pregunta)
    campo_fecha = "imported_at" if re.search(r"IMPORT|CARG|SUBID", texto) else "fecha_envio"
    return consultar_transmittals_periodo(
        inicio,
        fin,
        "fecha de carga" if campo_fecha == "imported_at" else "fecha de envío",
        campo_fecha,
        etiqueta,
    )


def consultar_transmittals_periodo(inicio, fin, fuente="fecha de envío", campo_fecha="fecha_envio", etiqueta=None):
    """Consulta el rango de fechas usando la fecha funcional o la fecha de carga."""
    etiqueta = etiqueta or (inicio.strftime("%d/%m/%Y") if fin == inicio + timedelta(days=1) else f"{inicio} a {fin - timedelta(days=1)}")
    if campo_fecha == "imported_at":
        inicio_dt = timezone.make_aware(datetime.combine(inicio, datetime.min.time()))
        fin_dt = timezone.make_aware(datetime.combine(fin, datetime.min.time()))
        transmittals = Transmital.objects.filter(imported_at__gte=inicio_dt, imported_at__lt=fin_dt)
    else:
        transmittals = Transmital.objects.filter(fecha_envio__gte=inicio, fecha_envio__lt=fin)
    transmittals = transmittals.order_by("consecutivo")
    codigos = list(transmittals.values_list("codigo_transmital", flat=True))
    if not codigos:
        return f"No se registraron transmittals en {etiqueta} según la {fuente}."
    lista = "\n".join(f"- {codigo}" for codigo in codigos)
    return f"Se encontraron {len(codigos)} transmittal(es) en {etiqueta} según la {fuente}:\n{lista}"


def consultar_documentos(pregunta):
    """Resuelve consultas frecuentes sin requerir Ollama ni generar SQL desde texto."""
    texto = _normalizar(pregunta)
    if re.search(r"TRANSMIT", texto) and _periodo_registro(pregunta):
        return consultar_transmittals(pregunta)
    referencia_match = re.search(r"(?:ODATA|TRN|PROY)[A-Z0-9-]*-\d{1,6}|\bTTAL[- ]?\d{1,6}\b|\b\d{1,6}\b", pregunta.upper())
    referencia = referencia_match.group(0) if referencia_match else ""

    if referencia and re.search(r"ADJUNT|ARCHIV|FICHER", texto):
        resultado = contar_adjuntos(referencia)
        if not resultado["ok"]:
            return resultado["respuesta"]
        return f"El transmittal {resultado['referencia']} tiene {resultado['cantidad']} {resultado['detalle']}."

    if re.search(r"\b(CUANTOS|CUANTAS|TOTAL|CANTIDAD)\b", texto) and re.search(r"DOCUMENT", texto):
        return f"Hay {Document.objects.count()} documentos registrados."

    if re.search(r"\b(LISTA|LISTAME|MUESTRAME|CUALES)\b", texto) and "DOCUMENT" in texto:
        documentos = Document.objects.order_by("-date", "-created_at")[:20]
        if not documentos:
            return "No hay documentos registrados."
        return "\n".join(f"- {document.code}: {document.title or 'sin título'}" for document in documentos)

    return "Puedo consultar documentos y adjuntos. Prueba: ¿cuántos archivos adjuntos tiene el transmittal TTAL-184?"


def ejecutar_consulta(intencion):
    """Compatibilidad con la interfaz semántica original, enfocada en documentos."""
    filtros = intencion.get("filtros", {})
    referencia = filtros.get("codigo") or filtros.get("referencia") or ""
    if intencion.get("operacion") == "contar_adjuntos":
        return contar_adjuntos(referencia)
    return {"ok": True, "cantidad": Document.objects.count(), "datos": []}
