import json

from .ollama import OllamaProvider
from ..domain.catalogo import SCHEMA_INTENCION
from ..prompts.sistema import SYSTEM_PROMPT


class InterpretacionInvalida(ValueError):
    pass


def interpretar(pregunta, provider=None):
    if not isinstance(pregunta, str) or not pregunta.strip():
        raise InterpretacionInvalida("La pregunta está vacía")
    provider = provider or OllamaProvider()
    content = provider.structured_chat(
        [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": pregunta.strip()},
        ],
        SCHEMA_INTENCION,
    )
    try:
        result = json.loads(content)
    except (TypeError, json.JSONDecodeError) as exc:
        raise InterpretacionInvalida("La respuesta de Ollama no es JSON válido") from exc
    if not isinstance(result, dict):
        raise InterpretacionInvalida("La intención debe ser un objeto JSON")
    return result
