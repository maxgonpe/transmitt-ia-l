from django.urls import path

from . import views

urlpatterns = [
    path("", views.consola, name="ia_consola"),
    path("consultar/", views.consultar, name="ia_consultar"),
    path("health/", views.health, name="ia_health"),
]
