"""
Django settings for condocdat project.

Control de documentos - datacenter en construcción.
"""

from pathlib import Path
import os

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Cargar variables de entorno desde .env (solo si existe). En producción se usan las del sistema.
_env_file = BASE_DIR / '.env'
if _env_file.exists():
    from dotenv import load_dotenv
    load_dotenv(_env_file)

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.environ.get('SECRET_KEY', 'django-insecure-change-me-in-production')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.environ.get('DEBUG', 'True') == 'True'

#ALLOWED_HOSTS = os.environ.get('ALLOWED_HOSTS', 'localhost,127.0.0.1,condocdat.netgogo.cl,www.condocdat.netgogo.cl').split(',')
ALLOWED_HOST = ['localhost']

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'documents',
    'rdi',
    'equipos',
    'gantt',
    'transmital',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'transmitt_ia_l.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'transmitt_ia_l.wsgi.application'

# Database - En local (DEBUG=True) PostgreSQL por defecto; en producción vía env
# Para no dejar contraseña en código, define DB_PASSWORD (y opcionalmente DB_USER, etc.) en el entorno.
if os.environ.get('DB_ENGINE'):
    DB_ENGINE = os.environ.get('DB_ENGINE')
else:
    DB_ENGINE = 'django.db.backends.postgresql' if DEBUG else 'django.db.backends.sqlite3'

if DB_ENGINE == 'django.db.backends.postgresql':
    DATABASES = {
        'default': {
            'ENGINE': DB_ENGINE,
            'NAME': os.environ.get('DB_NAME', 'condocdat_db'),
            'USER': os.environ.get('DB_USER', 'maxgonpe'),
            'PASSWORD': os.environ.get('DB_PASSWORD', 'celsa1961'),
            'HOST': os.environ.get('DB_HOST', 'localhost'),
            'PORT': os.environ.get('DB_PORT', '5432'),
            'CONN_MAX_AGE': 60,
        }
    }
else:
    DB_NAME = os.environ.get('DB_NAME', str(BASE_DIR / 'db.sqlite3'))
    if isinstance(DB_NAME, str) and Path(DB_NAME).is_absolute():
        DB_NAME_STR = DB_NAME
    else:
        DB_NAME_STR = str(BASE_DIR / DB_NAME) if isinstance(DB_NAME, str) else str(DB_NAME)
    DATABASES = {
        'default': {
            'ENGINE': DB_ENGINE,
            'NAME': DB_NAME_STR,
        }
    }

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# Internationalization
LANGUAGE_CODE = 'es-cl'
TIME_ZONE = 'America/Santiago'
USE_I18N = True
USE_TZ = True

# Static files
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [BASE_DIR / 'static'] if (BASE_DIR / 'static').exists() else []
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Carpeta doc/ del proyecto (plantillas transmital, Excel de referencia, creador de carpetas).
# En Docker es típicamente /app/doc. En el host se puede montar un volumen o definir CONDOCDAT_DOC_ROOT.
_doc_root_env = (os.environ.get('CONDOCDAT_DOC_ROOT') or '').strip()
CONDOCDAT_DOC_ROOT = Path(_doc_root_env).expanduser() if _doc_root_env else (BASE_DIR / 'doc')

# LibreOffice (soffice) para exportar transmittal XLSX → PDF. En Docker suele ser /usr/bin/soffice.
_soffice_env = (os.environ.get('SOFFICE_PATH') or os.environ.get('LIBREOFFICE_PATH') or '').strip()
SOFFICE_PATH = Path(_soffice_env).expanduser() if _soffice_env else None

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Login (vista propia /login/)
LOGIN_REDIRECT_URL = '/'
LOGIN_URL = '/login/'

# CSRF / Traefik (igual que mantto: sin dominio de cookie)
CSRF_TRUSTED_ORIGINS = [
    'https://condocdat.netgogo.cl',
    'https://www.condocdat.netgogo.cl',
    'http://condocdat.netgogo.cl',
    'http://www.condocdat.netgogo.cl',
    'http://127.0.0.1:8000',
    'http://localhost:8000',
]
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
# En HTTP local, cookies Secure=no se guardan → sesión/CSRF fallan (bucles o POST que no “termina” bien)
CSRF_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_HTTPONLY = False
CSRF_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_SECURE = not DEBUG
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'
SECURE_SSL_REDIRECT = False

# Email (Outlook / Office 365). Credenciales por entorno; nunca la contraseña en código.
# Para max.gonzalez@propamat.cl usar SMTP de Office 365; si tienes 2FA, crea una "Contraseña de aplicación" en cuenta Microsoft.
EMAIL_BACKEND = os.environ.get(
    'EMAIL_BACKEND',
    'django.core.mail.backends.smtp.EmailBackend'
)
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'smtp.office365.com')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', '587'))
EMAIL_USE_TLS = os.environ.get('EMAIL_USE_TLS', 'True').lower() in ('true', '1', 'yes')
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', 'max.gonzalez@propamat.cl')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')  # Obligatorio en producción vía .env
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', EMAIL_HOST_USER)
# Evita que el envío SMTP cuelgue indefinidamente (el navegador queda “cargando”)
EMAIL_TIMEOUT = int(os.environ.get('EMAIL_TIMEOUT', '180'))
# Límites envío correo (Office 365 ~25 MB mensaje; base64 suma ~37 %)
EMAIL_MAX_ATTACHMENT_BYTES = int(os.environ.get('EMAIL_MAX_ATTACHMENT_BYTES', str(22 * 1024 * 1024)))
EMAIL_MAX_ATTACHMENTS = int(os.environ.get('EMAIL_MAX_ATTACHMENTS', '30'))
EMAIL_MAX_RECIPIENTS = int(os.environ.get('EMAIL_MAX_RECIPIENTS', '500'))
# Subidas multipart grandes (muchos adjuntos): memoria antes de volcar a disco temporal
DATA_UPLOAD_MAX_MEMORY_SIZE = int(os.environ.get('DATA_UPLOAD_MAX_MEMORY_SIZE', str(64 * 1024 * 1024)))
FILE_UPLOAD_MAX_MEMORY_SIZE = int(os.environ.get('FILE_UPLOAD_MAX_MEMORY_SIZE', str(8 * 1024 * 1024)))
